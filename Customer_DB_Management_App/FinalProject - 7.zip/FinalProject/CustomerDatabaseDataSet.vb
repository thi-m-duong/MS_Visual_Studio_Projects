﻿

Partial Public Class CustomerDatabaseDataSet
End Class
